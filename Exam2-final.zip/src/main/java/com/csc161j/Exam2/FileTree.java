package com.csc161j.Exam2;

import java.io.File;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;

public class FileTree implements Iterable<FileNode> {

    private FileNode root;

    public FileTree(String path) {
        root = new FileNode(path);
        buildTree(root);
    }

    /** Return a depth-first post-order traversal iterator. */
    @Override
    public Iterator<FileNode> iterator() {
        return new DepthFirstIterator();
    }

    /**
     * Recursively build the tree from the directory structure.
     * Each directory's children are added to its FileNode, then
     * buildTree is called for each child.
     */
    private void buildTree(FileNode fileNode) {
        File file = fileNode.getFile();

        if (!file.isDirectory()) {
            return;
        }

        File[] files = file.listFiles();
        // listFiles() can return null if the directory cannot be read.
        if (files == null) {
            return;
        }

        for (File childFile : files) {
            FileNode childNode = new FileNode(childFile);
            fileNode.getChildNodes().add(childNode);
            buildTree(childNode);
        }
    }

    /** Iterator that performs an iterative post-order traversal using two stacks. */
    private class DepthFirstIterator implements Iterator<FileNode> {
        private Deque<FileNode> resultStack = new ArrayDeque<FileNode>();

        public DepthFirstIterator() {
            if (root != null) {
                Deque<FileNode> workStack = new ArrayDeque<FileNode>();
                workStack.push(root);

                // The second stack reverses the root-first traversal,
                // producing left-to-right post-order when popped.
                while (!workStack.isEmpty()) {
                    FileNode current = workStack.pop();
                    resultStack.push(current);

                    for (FileNode child : current.getChildNodes()) {
                        workStack.push(child);
                    }
                }
            }
        }

        @Override
        public boolean hasNext() {
            return !resultStack.isEmpty();
        }

        @Override
        public FileNode next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return resultStack.pop();
        }
    }

    /** Returns an iterator that performs a breadth-first traversal using a queue. */
    public Iterator<FileNode> breadthFirstIterator() {
        return new BreadthFirstIterator();
    }

    /** Iterator that visits each level of the tree before moving to the next. */
    private class BreadthFirstIterator implements Iterator<FileNode> {
        private Queue<FileNode> queue = new ArrayDeque<FileNode>();

        public BreadthFirstIterator() {
            if (root != null) {
                queue.add(root);
            }
        }

        @Override
        public boolean hasNext() {
            return !queue.isEmpty();
        }

        @Override
        public FileNode next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            FileNode current = queue.remove();
            for (FileNode child : current.getChildNodes()) {
                queue.add(child);
            }
            return current;
        }
    }
}
